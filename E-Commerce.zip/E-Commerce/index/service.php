<!Doctype html>
<html>

<head>
    
    <title>Service page</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/consumer_home.css">


</head>

<body>
    <?php include 'ls.php';?>
    <?php include 'static_header.php'; ?>  
    <div class="menu">

</div> 
 <div class="container">
        <div class="row">
            <div class="col-1"></div>
            
            <div class="col-10">
            
                <div class="box">
                    <div class="abc">
                    </div>
                    
                     <h2>Our sevices</h2>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe a nesciunt voluptatem modi et ratione quo nostrum magni? Quasi, odit iste! Praesentium reprehenderit doloribus omnis dolore aut? Ex, porro veniam?</p>
                    
                    <br>
                    
                    
                    
                   




                </div>




           
            </div>


            
            <div class="col-1"></div>
            
        </div>
        <?php include 'static_footer.php'; ?>
    </div>



   


</body>


</html>