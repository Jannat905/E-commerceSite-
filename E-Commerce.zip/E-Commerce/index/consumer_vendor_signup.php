
<!Doctype html>
<html>

<head>
    
    <title>Consumer Home page</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/consumer_home.css">


</head>

<body>

<?php include 'static_header.php'; ?>  
    <div class="menu">

</div> 
 <div class="container">
        <div class="row">
            <div class="col-1"></div>
            
            <div class="col-10">
            
                <div class="box">
                    <div class="abc">
                   <!--  <img src="logo.png" alt="logo"> -->
                    </div>
                    
                     <h2>SignUp page</h2>
                    <button onclick="location.href='Consumer_Sign-up.php'"class="button"><b>SignUp as a Consumer</b></button>
                                     
                    
                    <button onclick="location.href='vendor_signup.php'"class="button"><b>SignUp as a Vendor</b></button>
                    <br>
                    
                    
                    
                   




                </div>




           
            </div>


            
            <div class="col-1"></div>
            
        </div>
        <?php include 'static_footer.php'; ?>
    </div>



   


</body>


</html>