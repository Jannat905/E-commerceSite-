<Doctype html>
<html>

<head>
    
    <title>Manager Salary page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/Manager_Salary_style.css">


</head>

<body>
<?php include("static_header.php")
    ?>
    <div class="container">
        <div class="row">
            <div class="col-1"></div>
            
            <div class="col-10">
            
                <div class="box">
                    <div class="abc">
                    <a href="Manager_Homepage.php" ></a>
                    </div>
                    <h3> Manager Salary </h3>
                    <br>

                   
                    <button onclick="location.href='Manager_payment.php'" class="button"><b>Withdraw Salary</b></button>
                    <br>
                    <button onclick="location.href='bonus_request.php'" class="button"><b>Request For Bonus</b></button>


                    
                    
                    
                    
                    
                   






                </div>




           
            </div>

            <div class="col-1"></div>
            
        </div>
        <?php include('static_footer.php')
        ?>
    </div>



</body>


</html>