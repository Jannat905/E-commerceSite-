<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie-edge">
<title>Static Home</title>
    
<link rel="stylesheet" href="stylesheet/head_style.css">  

  
</head>
<body>

<div class="img">

  <img class="img" src="images/logo.png" alt="logo">

</div>






<div class="nav">

  <ul>
  <button onclick="location.href='static.php'"class="button">Home</button>
    <button onclick="location.href='service.php'"class="button">Service</button> 
    <button onclick="location.href='about.php'"class="button">About Us</button>
    <button onclick="location.href='contact.php'"class="button">Contact</button>
    <button onclick="location.href='consumer_cart.php'"class="button">Cart</button>

  </ul>
</div>

<!-- <div class="content1">
  <p>
   hh hhh
  </p>
</div>
 -->

<!--
<div class="content2">
  <p>
   hh
  </p>
</div>
-->

</body>
</html>