<Doctype html>
<html>

<head>
    
    <title>Manager Complaint page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/Manager_Complaintstyle.css">


</head>

<body>
<?php include("static_header.php")
    ?>
    <div class="container">
        <div class="row">
            <div class="col-1"></div>
            
            <div class="col-10">
            
                <div class="box">
                    <div class="abc">
                    <a href="Manager_Homepage.php" ></a>
                    </div>
                    <h3>Manager Complaint</h3>
                    <br>

                    <button onclick="location.href='consumer_list.php'" class="button"><b>View Consumer List</b></button>
                    
                    <button onclick="location.href='vcomplains.php'" class="button"><b>Complaints</b></button>
                    
                   






                </div>




           
            </div>

            <div class="col-1"></div>
            
        </div>
        <?php include('static_footer.php')
        ?>
    </div>



</body>


</html>