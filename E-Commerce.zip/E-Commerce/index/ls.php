<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie-edge">
<title>Static</title>
<link rel="stylesheet" href="stylesheet/ls.css">



<div class="topnav">
<button onclick="location.href='login.php'"class= "button1">Login</button>
<button onclick="location.href='consumer_vendor_signup.php'"class= "button2">SignUp</button>
</div>



</body>
</html>