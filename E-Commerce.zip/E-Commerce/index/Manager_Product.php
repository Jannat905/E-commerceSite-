<Doctype html>
<html>

<head>
    
    <title>Manager Product page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesheet/Manager_Product_style.css">


</head>

<body>
<?php include("static_header.php")
    ?>
    <div class="container">
        <div class="row">
            <div class="col-1"></div>
            
            <div class="col-10">
            
                <div class="box">
                    <div class="abc">
                    <a href="Manager_Homepage.php" ></a>
                    </div>
                    <h3>Manager Product</h3>
                    <br>

                    <button onclick="location.href='product_list.php'" class="button"><b>View Product List</b></button>
                    
                    
                    
                    
                    
                   






                </div>




           
            </div>

            <div class="col-1"></div>
            
        </div>
        <?php include('static_footer.php')
        ?>
    </div>



</body>


</html>